const express = require('express');
const router = express.Router();
const path = require('path');
const { requireAuth } = require('../middleware/auth');
const { get, all, run } = require('../db/init');
const { getCourseById, getCoursesByCategory, getCategoryOrder, courses } = require('../utils/courses');

// Landing page
router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// Checkout
router.get('/checkout', (req, res) => {
  res.render('checkout', { title: 'Checkout — Chefless Cafe Menu System', razorpayKey: process.env.RAZORPAY_KEY_ID });
});

// Thank you — with auto-login via one-time token
router.get('/thankyou', (req, res) => {
  const token = req.query.token;
  if (token) {
    const user = get('SELECT id, name, email FROM users WHERE reset_token = ? AND reset_expires > datetime("now")', [token]);
    if (user) {
      // Auto-login: set session
      req.session.userId = user.id;
      req.session.userName = user.name;
      req.session.userEmail = user.email;
      // Clear the one-time token
      run('UPDATE users SET reset_token = NULL, reset_expires = NULL WHERE id = ?', [user.id]);
      console.log('[AUTO-LOGIN] ✅ User auto-logged in:', user.email);
      // CRITICAL: save session to store BEFORE rendering — ensures
      // the session cookie is committed so /dashboard redirect works
      return req.session.save((err) => {
        if (err) console.error('[AUTO-LOGIN] Session save error:', err);
        res.render('thankyou', { title: 'Thank You! — The Chai Dealer' });
      });
    } else {
      console.log('[AUTO-LOGIN] ⚠ Invalid or expired token');
    }
  }
  res.render('thankyou', { title: 'Thank You! — The Chai Dealer' });
});

// Login
router.get('/login', (req, res) => {
  if (req.session && req.session.userId) return res.redirect('/dashboard');
  res.render('login', { title: 'Login — The Chai Dealer', error: null });
});

// Forgot password
router.get('/forgot-password', (req, res) => {
  res.render('forgot-password', { title: 'Forgot Password — The Chai Dealer', message: null, error: null, waFallbackUrl: null });
});

// Reset password
router.get('/reset-password/:token', (req, res) => {
  const user = get('SELECT id FROM users WHERE reset_token = ? AND reset_expires > datetime("now")', [req.params.token]);
  if (!user) {
    return res.render('forgot-password', { title: 'Forgot Password', message: null, error: 'Invalid or expired reset link. Please request a new one.' });
  }
  res.render('reset-password', { title: 'Reset Password — The Chai Dealer', token: req.params.token, error: null });
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// Dashboard
router.get('/dashboard', requireAuth, (req, res) => {
  const user = get('SELECT * FROM users WHERE id = ?', [req.session.userId]);
  const countRow = get('SELECT COUNT(*) as count FROM progress WHERE user_id = ? AND completed = 1', [req.session.userId]);
  const completedCount = countRow ? countRow.count : 0;
  const totalCourses = courses.length;
  const progressPercent = Math.round((completedCount / totalCourses) * 100);

  res.render('dashboard', {
    title: 'Dashboard — The Chai Dealer', userName: user.name,
    completedCount, totalCourses, progressPercent, courses,
  });
});

// Courses list
router.get('/courses', requireAuth, (req, res) => {
  const categorized = getCoursesByCategory();
  const categoryOrder = getCategoryOrder();
  const completedRows = all('SELECT course_id FROM progress WHERE user_id = ? AND completed = 1', [req.session.userId]);
  const completed = completedRows.map(r => r.course_id);

  res.render('courses', { title: 'All Courses — The Chai Dealer', categorized, categoryOrder, completed });
});

// Course detail
router.get('/course/:id', requireAuth, (req, res) => {
  const course = getCourseById(req.params.id);
  if (!course) return res.status(404).render('error', { title: '404', message: 'Course not found.' });

  const prog = get('SELECT completed FROM progress WHERE user_id = ? AND course_id = ?', [req.session.userId, course.id]);
  const questions = all(`
    SELECT q.*, u.name as author_name FROM questions q 
    JOIN users u ON q.user_id = u.id 
    WHERE q.course_id = ? 
    ORDER BY q.created_at DESC
  `, [course.id]);

  questions.forEach(q => {
    q.answers = all('SELECT * FROM answers WHERE question_id = ? ORDER BY created_at ASC', [q.id]);
  });

  const idx = courses.findIndex(c => c.id === course.id);
  const prev = idx > 0 ? courses[idx - 1] : null;
  const next = idx < courses.length - 1 ? courses[idx + 1] : null;

  res.render('course-detail', {
    title: `${course.name} — The Chai Dealer`, course,
    isCompleted: prog && prog.completed === 1, questions, prev, next,
    coursesByCategory: getCoursesByCategory(),
    categoryOrder: getCategoryOrder(),
  });
});

module.exports = router;
